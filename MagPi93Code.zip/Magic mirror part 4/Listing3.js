start: function() {
  Log.info("Starting module: " + this.name);

  var self = this;

  // Schedule update timer.
  setInterval(function() {
    self.updateDom(self.config.fadeSpeed);
  }, this.config.updateInterval);
},